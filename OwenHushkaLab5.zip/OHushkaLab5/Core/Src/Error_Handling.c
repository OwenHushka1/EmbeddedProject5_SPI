#include <Error_Handling.h>
#include <stdio.h>


void APPLICATION_ASSERT(bool var){

	if(var == false){
		printf("Error Occured");
		while(1<3){

		}
	}
}

