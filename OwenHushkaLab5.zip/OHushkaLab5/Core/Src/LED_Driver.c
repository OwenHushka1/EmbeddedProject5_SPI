/*
 * LED_Driver.c
 *
 *  Created on: Sep 5, 2023
 *      Author: owenhushka
 */


#include <LED_Driver.h>

static GPIO_InitTypeDef GreenLED;
static GPIO_InitTypeDef RedLED;


void initializeLED(uint16_t whichLED){

	switch (whichLED){
	  case RED:
		  RedLED.Mode = GPIO_MODE_OUTPUT_PP;
		  RedLED.Speed = GPIO_SPEED_FREQ_HIGH;
		  RedLED.Pin = GPIO_PIN_14;
		  RedLED.Pull = GPIO_NOPULL;

		  __HAL_RCC_GPIOG_CLK_ENABLE();
		  HAL_GPIO_Init(GPIOG, &RedLED);
	  break;

	  case GREEN:
		  GreenLED.Mode = GPIO_MODE_OUTPUT_PP;
		  GreenLED.Speed = GPIO_SPEED_FREQ_HIGH;
		  GreenLED.Pin = GPIO_PIN_14;
		  RedLED.Pull = GPIO_NOPULL;
		  __HAL_RCC_GPIOG_CLK_ENABLE();
		  HAL_GPIO_Init(GPIOG, &GreenLED);
	  break;

	}
}


void toggleLED(uint16_t whichLED){
	HAL_GPIO_TogglePin(GPIOG, whichLED);
}


void disableLED(uint16_t whichLED){
	HAL_GPIO_WritePin(GPIOG, whichLED, GPIO_PIN_RESET);
}

void enableLED(uint16_t whichLED){
	HAL_GPIO_WritePin(GPIOG, whichLED, GPIO_PIN_SET);
}
