#include "GYRO_Driver.h"
#include "stm32f4xx_hal_spi.h"

#define TESTING_TIMEOUT 25000

static GPIO_InitTypeDef GYRO_Ctrl;
static SPI_HandleTypeDef handle;
static HAL_StatusTypeDef gyroHALStatus; //variable to store HAl status

#define GYRO_CRCC_POLYNOMIAL 10

#define CS_PORT GPIOC

#define CS_PIN GPIO_PIN_1

#define I3G4250D_READ (1<<0x7)

#define GYRO_power_on 0x0800

#define I3G4250D_WRITE (0<<7) //write mode

#define SET_XYZ_AND_PD (0xF)

#define SET_FULL_SCALE_500 (0x10)

#define REBOOT_AND_FIFO_ENABLE (0xC0)

#define STREAM_MODE (0x40)//fifo mode stream 0x40

#define TEMP_BITS (0xFF)



void GYRO_INIT(){

	//SCK is PF7
	//MISO is PF8
	//MOSI is PF9
	//MEMS SPI PC1
	//PA2 MEMS INIT 2
	//PA1 MEMS INIT 1

	//PF7 SCLK, MISO PF8, MOSI PF9
	GYRO_Ctrl.Pin = (GPIO_PIN_7 | GPIO_PIN_8 | GPIO_PIN_9);
	GYRO_Ctrl.Mode = GPIO_MODE_AF_PP;
	GYRO_Ctrl.Pull = GPIO_NOPULL;
	GYRO_Ctrl.Speed = GPIO_SPEED_FREQ_LOW;
	GYRO_Ctrl.Alternate = GPIO_MODE_AF_PP;

	//GPIOF
	__HAL_RCC_GPIOF_CLK_ENABLE(); //Enable_Clock();
	HAL_GPIO_Init(GPIOF, &GYRO_Ctrl);//GPIO_Initialize(&ButtonConfig);


	//PC1 is Chip select
	GYRO_Ctrl.Pin = GPIO_PIN_1;
	GYRO_Ctrl.Pull = GPIO_PULLUP;
	GYRO_Ctrl.Mode = GPIO_MODE_OUTPUT_OD;


	__HAL_RCC_GPIOC_CLK_ENABLE();
	HAL_GPIO_Init(GPIOC, &GYRO_Ctrl);


	SPI_InitTypeDef GYRO_Control = {0};

	handle.Init.Mode = SPI_MODE_MASTER;
	handle.Init.Direction = SPI_DIRECTION_2LINES;

	handle.Init.DataSize = SPI_DATASIZE_8BIT;
	handle.Init.CLKPolarity = SPI_POLARITY_HIGH;
	handle.Init.CLKPhase = SPI_PHASE_2EDGE;
	handle.Init.NSS = SPI_NSS_SOFT;

	handle.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_64;
	handle.Init.FirstBit = SPI_FIRSTBIT_MSB;
	handle.Init.TIMode = SPI_TIMODE_DISABLE;
	handle.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
	handle.Init.CRCPolynomial = 0;

	handle.Instance = SPI5;

	HAL_SPI_Init(&handle);
}

void GYRO_GetDeviceID(){



	//WHO_AM_I Address:  0F :Default 11010011


	uint8_t commandToSend = (I3G4250D_READ | WHO_AM_I);
	uint16_t receivedData = 0x00;
	uint16_t DataReturned;

	GYRO_Slave_Enable();
	while(HAL_GPIO_ReadPin(CS_PORT,CS_PIN) != GPIO_PIN_RESET ); // Wait for the communication line to be low.
	gyroHALStatus = HAL_SPI_TransmitReceive(&handle, &commandToSend,(uint8_t*) &receivedData, 2,TESTING_TIMEOUT);
	GYRO_Slave_Disable();
	if(gyroHALStatus != HAL_OK)
	{
	for(;;); // Infinite Loop to catch errors
	}
	DataReturned = (0xFF00 & receivedData) >> 8; // Shift the data to get the bytes we want
	printf("The Device ID is: %d \n", DataReturned);

	//cr 1 set bit 6 SPI enable 1: Peripheral enabled
}

void GYRO_PowerOn(){
	uint16_t commandToSend = (CTRL_REG1 | I3G4250D_READ);
	uint16_t receivedData = 0x00;
	uint16_t DataReturned;

	GYRO_Slave_Enable();

	while(HAL_GPIO_ReadPin(CS_PORT,CS_PIN) != GPIO_PIN_RESET ); // Wait for the communication line to be low.
	gyroHALStatus = HAL_SPI_TransmitReceive(&handle, (uint8_t*) &commandToSend,(uint8_t*) &receivedData, 2,TESTING_TIMEOUT);
	GYRO_Slave_Disable();
	if(gyroHALStatus != HAL_OK)
	{
	for(;;); // Infinite Loop to catch errors
	}

	DataReturned = (0xFF00 & receivedData);
	commandToSend = (DataReturned | GYRO_power_on | CTRL_REG1 | I3G4250D_WRITE);

	GYRO_Slave_Enable();

	while(HAL_GPIO_ReadPin(CS_PORT,CS_PIN) != GPIO_PIN_RESET ); // Wait for the communication line to be low.
	gyroHALStatus = HAL_SPI_Transmit(&handle, (uint8_t*) &commandToSend,2,TESTING_TIMEOUT);
	GYRO_Slave_Disable();
	if(gyroHALStatus != HAL_OK)
	{
	for(;;); // Infinite Loop to catch errors
	}
}


void GYRO_Reboot(){

	uint8_t commandToSend = (CTRL_REG1 | I3G4250D_READ);
		uint16_t receivedData = 0x00;


		GYRO_Slave_Enable();

		while(HAL_GPIO_ReadPin(CS_PORT,CS_PIN) != GPIO_PIN_RESET ); // Wait for the communication line to be low.
		gyroHALStatus = HAL_SPI_TransmitReceive(&handle, &commandToSend,(uint8_t*) &receivedData, 2,TESTING_TIMEOUT);
		GYRO_Slave_Disable();
		if(gyroHALStatus != HAL_OK)
		{
		for(;;); // Infinite Loop to catch errors
		}
}

void GYRO_GetTemp(){

	//TEMP_BITS
	uint8_t commandToSend = (OUT_TEMP | I3G4250D_READ);
	uint16_t receivedData = 0x00;
	uint16_t DataReturned;

	GYRO_Slave_Enable();

	while(HAL_GPIO_ReadPin(CS_PORT,CS_PIN) != GPIO_PIN_RESET ); // Wait for the communication line to be low.
	gyroHALStatus = HAL_SPI_TransmitReceive(&handle, &commandToSend,(uint8_t*) &receivedData, 2,TESTING_TIMEOUT);
	GYRO_Slave_Disable();
	if(gyroHALStatus != HAL_OK)
	{
	for(;;); // Infinite Loop to catch errors
	}

	DataReturned = (0xFF00 & receivedData) >> 8; // Shift the data to get the bytes we want
	printf("Temp Data: %d \n", DataReturned);
}



void GYRO_Register_Config(){
	uint16_t commandToSend = (CTRL_REG1 | I3G4250D_WRITE | (SET_XYZ_AND_PD << 8));
	uint16_t commandToSend2 = (CTRL_REG4 | I3G4250D_WRITE | (SET_FULL_SCALE_500<< 8));
	uint16_t commandToSend3 = (CTRL_REG5 | I3G4250D_WRITE | (REBOOT_AND_FIFO_ENABLE<< 8)); //0xC0 is what he had idk tho
	uint16_t commandToSend4 = (FIFO_CTRL_REG | (STREAM_MODE<< 8) | I3G4250D_WRITE);

	GYRO_Slave_Enable();

	while(HAL_GPIO_ReadPin(CS_PORT,CS_PIN) != GPIO_PIN_RESET ); // Wait for the communication line to be low.
	gyroHALStatus = HAL_SPI_Transmit(&handle, (uint8_t*)&commandToSend,2,TESTING_TIMEOUT);
	GYRO_Slave_Disable();
	if(gyroHALStatus != HAL_OK)
	{
	for(;;); // Infinite Loop to catch errors
	}


	GYRO_Slave_Enable();
	gyroHALStatus = HAL_SPI_Transmit(&handle, (uint8_t*)&commandToSend2,2,TESTING_TIMEOUT);
	GYRO_Slave_Disable();
	if(gyroHALStatus != HAL_OK)
	{
	for(;;); // Infinite Loop to catch errors
	}



	GYRO_Slave_Enable();
	gyroHALStatus = HAL_SPI_Transmit(&handle, (uint8_t*)&commandToSend3,2,TESTING_TIMEOUT);
	GYRO_Slave_Disable();
	if(gyroHALStatus != HAL_OK)
	{
	for(;;); // Infinite Loop to catch errors
	}



	GYRO_Slave_Enable();
	gyroHALStatus = HAL_SPI_Transmit(&handle, (uint8_t*)&commandToSend4,2,TESTING_TIMEOUT);
	GYRO_Slave_Disable();
	if(gyroHALStatus != HAL_OK)
	{
	for(;;); // Infinite Loop to catch errors
	}


}

void GYRO_VerifyHALStatus(){


	if(gyroHALStatus != HAL_OK)
	{
		for(;;); // Infinite Loop to catch errors
	}

}

void GYRO_Slave_Enable(){
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET);
}


void GYRO_Slave_Disable(){
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_SET);
}


void GYRO_GET_XYZ(){

	//TEMP_BITS
		uint8_t commandToSend1 = (OUT_X_L | I3G4250D_READ); //should i be calling the lower or higher registers?
		uint8_t commandToSend2 = (OUT_Y_L | I3G4250D_READ);
		uint8_t commandToSend3 = (OUT_Z_L | I3G4250D_READ);
		uint16_t receivedData1 = 0x00;
		uint16_t receivedData2 = 0x00;
		uint16_t receivedData3 = 0x00;

		HAL_StatusTypeDef gyroHALStatus = {0};
		uint16_t DataReturned;

		GYRO_Slave_Enable();


		while(HAL_GPIO_ReadPin(CS_PORT,CS_PIN) != GPIO_PIN_RESET ); // Wait for the communication line to be low.
		gyroHALStatus = HAL_SPI_TransmitReceive(&handle, &commandToSend1,(uint8_t*) &receivedData1, 2,TESTING_TIMEOUT);
		GYRO_Slave_Disable();
		if(gyroHALStatus != HAL_OK)
		{
		for(;;); // Infinite Loop to catch errors
		}

		DataReturned = (0xFF00 & receivedData1) >> 8; // Shift the data to get the bytes we want
		printf("X axis data: %d \n", DataReturned);
		DataReturned = 0x0000;



		GYRO_Slave_Enable();


		while(HAL_GPIO_ReadPin(CS_PORT,CS_PIN) != GPIO_PIN_RESET ); // Wait for the communication line to be low.
		gyroHALStatus = HAL_SPI_TransmitReceive(&handle, &commandToSend2,(uint8_t*) &receivedData2, 2,TESTING_TIMEOUT);
		GYRO_Slave_Disable();
		if(gyroHALStatus != HAL_OK)
		{
		for(;;); // Infinite Loop to catch errors
		}


		DataReturned = (0xFF00 & receivedData2) >> 8; // Shift the data to get the bytes we want
		printf("Y axis data: %d \n", DataReturned);
		DataReturned = 0x0000;



		GYRO_Slave_Enable();


		while(HAL_GPIO_ReadPin(CS_PORT,CS_PIN) != GPIO_PIN_RESET ); // Wait for the communication line to be low.
		gyroHALStatus = HAL_SPI_TransmitReceive(&handle, &commandToSend3,(uint8_t*) &receivedData3, 2,TESTING_TIMEOUT);
		GYRO_Slave_Disable();
		if(gyroHALStatus != HAL_OK)
		{
		for(;;); // Infinite Loop to catch errors
		}


		DataReturned = (0xFF00 & receivedData3) >> 8; // Shift the data to get the bytes we want
		printf("Z axis data: %d \n", DataReturned);
		DataReturned = 0x0000;

}





