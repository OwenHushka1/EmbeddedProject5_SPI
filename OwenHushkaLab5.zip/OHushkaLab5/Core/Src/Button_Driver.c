#include<Button_Driver.h>

void Initialize_Button(){
	GPIO_InitTypeDef ButtonConfig = {0};
	ButtonConfig.Mode = GPIO_MODE_INPUT;
	ButtonConfig.Pin = GPIO_PIN_0;
	ButtonConfig.Pull = GPIO_NOPULL;
	ButtonConfig.Speed = GPIO_SPEED_FREQ_HIGH;

	__HAL_RCC_GPIOA_CLK_ENABLE();
	HAL_GPIO_Init(GPIOA, &ButtonConfig);
}


void Initialize_Interrupt_Mode(){

	GPIO_InitTypeDef ButtonConfig = {0};

	ButtonConfig.Mode = GPIO_MODE_INPUT;
	ButtonConfig.Pin = GPIO_PIN_0;
	ButtonConfig.Pull = GPIO_NOPULL;
	ButtonConfig.Speed = GPIO_SPEED_FREQ_HIGH;

	__HAL_RCC_GPIOA_CLK_ENABLE(); //Enable_Clock();
	HAL_GPIO_Init(GPIOA, &ButtonConfig);
	HAL_NVIC_EnableIRQ(EXTI0_IRQ_NUMBER);
}

void Enable_Clock(){
	__HAL_RCC_GPIOA_CLK_ENABLE(); //Enable_Clock();
}


bool Return_Press(){
	if(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == GPIO_PIN_SET){
		return true;
	}
	else{
		return false;
	}
}

