/*
 * ApplicationCode.c
 *
 *  Created on: Sep 5, 2023
 *      Author: owenhushka
 */

#include"ApplicationCode.h"


static uint8_t CurrentLED;

void InitializeGreenLED(){
	initializeLED(GREEN);

}
void InitializeRedLED(){
	initializeLED(RED);

}
void InitializeBothLED(){

	initializeLED(RED);
	initializeLED(GREEN);
}

void ToggleGreen(){

	toggleLED(GREEN);
}
void ToggleRed(){

	toggleLED(RED);

}


void TurnRedOn(){

	enableLED(RED);

}
void TurnGreenOn(){
	enableLED(GREEN);

}

void TurnRedOff(){

	disableLED(RED);

}
void TurnGreenOff(){

	disableLED(GREEN);
}

void Delay(){
	char arr[NAME_LENGTH] = "Owen";
	[[maybe_unused]]char destination[NAME_LENGTH];

	for(int i = 0; i < DELAY; i++){
		for(int k = 0; k < 4; k++){
			destination[k] = arr[k];
		}
	}
}

void InitializeInterruptMode(){

	Initialize_Interrupt_Mode();
}


void Button_Init(){
	Initialize_Button();
}

void Application_Init(){
	#if USE_INTERRUPT_FOR_BUTTON != 0
		InitializeInterruptMode();
	#else
		Button_Init();
	#endif

	InitializeGreenLED();  //different LED than last time
	CurrentLED = GREEN; //setting CurrentLED to green LED macro
	TurnGreenOff();//deactivate LED so it's at known state


	addSchedulerEvent(DELAY_EVENT);//add Delay event
	addSchedulerEvent(POLL_BUTTON_EVENT);
	addSchedulerEvent(GET_GYRO_TEMP);
	addSchedulerEvent(GET_GYRO_AXIS_DATA);
	addSchedulerEvent(REBOOT_GYRO);
}






void ButtonPollingRoutine(){
	if(Return_Press()){
		TurnGreenOn();
	}
	else{
		TurnGreenOff();
	}
}

void EXTI0_IRQHandler(){
	IRQ_DISABLE_INTERRUPT(EXTI0_IRQ_NUMBER);
	if(CurrentLED == GREEN){
		ToggleGreen();
	}
	EXTI_INTERRUPT_CLEAR(GPIO_PIN_0);
	IRQ_ENABLE_INTERRUPT(EXTI0_IRQ_NUMBER);


}



