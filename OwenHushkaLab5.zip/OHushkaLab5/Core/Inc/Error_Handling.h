//just need application assert function

#include <stdbool.h>

void APPLICATION_ASSERT(bool var);

