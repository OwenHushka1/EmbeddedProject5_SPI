/*
 * Scheduler.h
 *
 *  Created on: Sep 5, 2023
 *      Author: owenhushka
 */

#ifndef INC_SCHEDULER_H_
#define INC_SCHEDULER_H_
#include <Button_Driver.h>
#include <stdint.h>


#define DELAY_EVENT (1<<0)
#define LED_TOGGLE_EVENT (1<<1)
#define POLL_BUTTON_EVENT (1<<2)
#define GET_GYRO_TEMP (1<<3)
#define GET_GYRO_AXIS_DATA (1<<4)
#define REBOOT_GYRO (1<<5)


uint32_t getScheduledEvents();
void addSchedulerEvent(uint32_t event);
void removeSchedulerEvent(uint32_t event);

#endif /* INC_SCHEDULER_H_ */




