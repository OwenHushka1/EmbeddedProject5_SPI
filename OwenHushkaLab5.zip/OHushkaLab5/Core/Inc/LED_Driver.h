/*
 * LED_Driver.h
 *
 *  Created on: Sep 5, 2023
 *      Author: owenhushka
 */


#ifndef INC_LED_DRIVER_H_
#define INC_LED_DRIVER_H_


#include "stm32f4xx_hal.h"


#define RED 0
#define GREEN 1

void initializeLED(uint16_t whichLED);
void enableClock(uint16_t whichLED);
void enableLED(uint16_t whichLED);
void disableLED(uint16_t whichLED);
void toggleLED(uint16_t whichLED);

#endif /* INC_LED_DRIVER_H_ */


